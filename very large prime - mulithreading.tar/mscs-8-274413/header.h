#ifndef header_H   
#define header_H

const int numOfThreads =5;  


bool isPrime( long long n, long long lo, long long hi );
int main(int argc, char* argv[]);

#endif

